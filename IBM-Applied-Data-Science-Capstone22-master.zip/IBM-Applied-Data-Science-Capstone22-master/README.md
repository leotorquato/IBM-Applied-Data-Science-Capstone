# IBM Applied Data Science Capstone
The Battle of Neighborhoods: Venue Comparison in the Dallas-Fort Worth Metroplex

A capstone project completed for IBM Data Science certificate

By: Leonardo Torquato
